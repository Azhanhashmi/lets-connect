export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  interests?: string[];
  lookingFor?: string[];
  socialLinks?: { platform: string; url: string }[];
  location?: string;
  createdAt: string;
}

export interface Profile extends User {
  connectionsCount: number;
  isConnected?: boolean;
  requestSent?: boolean;
}

export interface ConnectRequest {
  id: string;
  sender: Profile;
  receiver: Profile;
  message?: string;
  status: 'pending' | 'accepted' | 'passed' | 'later';
  createdAt: string;
}

export interface Connection {
  id: string;
  user: Profile;
  connectedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  sender: User;
  content: string;
  read: boolean;
  createdAt: string;
}

export interface Conversation {
  id: string;
  participant: Profile;
  lastMessage?: Message;
  unreadCount: number;
  updatedAt: string;
}

export interface Compliment {
  id: string;
  sender?: User;
  receiver: User;
  content: string;
  approved: boolean;
  anonymous: boolean;
  createdAt: string;
}

export interface Question {
  id: string;
  asker?: User;
  target: User;
  content: string;
  answer?: string;
  anonymous: boolean;
  createdAt: string;
  answeredAt?: string;
}

export interface Notification {
  id: string;
  type: 'request' | 'accepted' | 'message' | 'compliment' | 'question' | 'answer';
  content: string;
  read: boolean;
  relatedUser?: User;
  relatedId?: string;
  createdAt: string;
}

export interface ApiResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

export interface AuthResponse {
  token: string;
  user: User;
}
