import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Heart, HelpCircle, MapPin, Link2, Send, UserPlus } from 'lucide-react';
import { useProfile } from '../hooks/useProfile';
import { useCompliments, useSendCompliment } from '../hooks/useCompliments';
import { useQuestions, useAskQuestion } from '../hooks/useQuestions';
import { useRequestActions } from '../hooks/useRequests';
import { Avatar } from '../components/ui/Avatar';
import { Tag } from '../components/ui/Tag';
import { Spinner } from '../components/ui/Spinner';

export const PublicProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const navigate = useNavigate();
  const { data: profile, isLoading } = useProfile(username!);
  const { data: compliments } = useCompliments(username!);
  const { data: questions } = useQuestions(username!);
  const sendRequest = useRequestActions().send;
  const sendCompliment = useSendCompliment();
  const askQuestion = useAskQuestion();

  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showComplimentModal, setShowComplimentModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [connectMsg, setConnectMsg] = useState('');
  const [complimentText, setComplimentText] = useState('');
  const [questionText, setQuestionText] = useState('');
  const [anon, setAnon] = useState(false);

  const approvedCompliments = Array.isArray(compliments) ? compliments.filter((c: any) => c.approved) : [];
  const answeredQuestions = Array.isArray(questions) ? questions.filter((q: any) => q.answer) : [];

  if (isLoading) return <div className="flex justify-center pt-20"><Spinner /></div>;
  if (!profile) return <div className="text-center pt-20 font-sans text-[#1A1A1A]/40">Profile not found</div>;

  const handleConnect = () => {
    sendRequest.mutate({ receiverId: profile.id, message: connectMsg });
    setShowConnectModal(false);
  };

  const handleCompliment = () => {
    sendCompliment.mutate({ receiverId: profile.id, content: complimentText, anonymous: anon });
    setComplimentText('');
    setShowComplimentModal(false);
  };

  const handleQuestion = () => {
    askQuestion.mutate({ targetId: profile.id, content: questionText, anonymous: anon });
    setQuestionText('');
    setShowQuestionModal(false);
  };

  const Modal: React.FC<{ onClose: () => void; title: string; children: React.ReactNode }> = ({ onClose, title, children }) => (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end justify-center p-4"
      onClick={onClose}>
      <motion.div initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="bg-[#FFFEFD] rounded-3xl p-6 w-full max-w-sm"
        onClick={(e) => e.stopPropagation()}>
        <h3 className="font-serif text-xl text-[#1A1A1A] mb-4">{title}</h3>
        {children}
      </motion.div>
    </motion.div>
  );

  return (
    <div className="pb-32">
      {/* Back */}
      <div className="px-5 pt-12 pb-0">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-[#1A1A1A]/40 hover:text-[#1A1A1A] transition-colors font-sans mb-4">
          <ArrowLeft size={14} /> Back
        </button>
      </div>

      {/* Hero */}
      <div className="relative">
        <div className="h-40 bg-gradient-to-br from-[#994EA8]/10 to-[#1A1A1A]/5" />
        <div className="px-5 -mt-14">
          <div className="mb-4">
            <Avatar src={profile.avatar} name={profile.name} size="xl" className="ring-4 ring-[#FFFEFD] shadow-lg" />
          </div>
          <h1 className="font-serif text-2xl text-[#1A1A1A] mb-0.5">{profile.name}</h1>
          <p className="text-sm text-[#1A1A1A]/40 font-sans mb-2">@{profile.username}</p>
          {profile.location && (
            <div className="flex items-center gap-1.5 mb-3">
              <MapPin size={13} className="text-[#1A1A1A]/35" />
              <span className="text-xs text-[#1A1A1A]/45 font-sans">{profile.location}</span>
            </div>
          )}
          {profile.bio && <p className="text-sm text-[#1A1A1A]/65 font-sans leading-relaxed mb-5">{profile.bio}</p>}

          {profile.interests && profile.interests.length > 0 && (
            <div className="mb-4">
              <p className="text-[10px] uppercase tracking-wider text-[#1A1A1A]/35 font-sans mb-2">Interests</p>
              <div className="flex flex-wrap gap-2">{profile.interests.map((i: string) => <Tag key={i} label={i} />)}</div>
            </div>
          )}
          {profile.lookingFor && profile.lookingFor.length > 0 && (
            <div className="mb-4">
              <p className="text-[10px] uppercase tracking-wider text-[#1A1A1A]/35 font-sans mb-2">Looking for</p>
              <div className="flex flex-wrap gap-2">{profile.lookingFor.map((l: string) => <Tag key={l} label={l} variant="purple" />)}</div>
            </div>
          )}
          {profile.socialLinks && profile.socialLinks.length > 0 && (
            <div className="mb-5 flex flex-col gap-2">
              {profile.socialLinks.map((link: { platform: string; url: string }) => (
                <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-[#994EA8] font-sans hover:underline">
                  <Link2 size={13} /> {link.platform}
                </a>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="h-px bg-black/6 mx-5 my-6" />

      {/* Compliments */}
      {approvedCompliments.length > 0 && (
        <div className="px-5 mb-6">
          <h2 className="font-serif text-lg text-[#1A1A1A] mb-3">Compliments</h2>
          <div className="space-y-3">
            {approvedCompliments.map((c: any) => (
              <div key={c.id} className="bg-black/3 rounded-2xl p-4">
                <p className="text-sm font-sans text-[#1A1A1A]/70 italic">"{c.content}"</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Q&A */}
      {answeredQuestions.length > 0 && (
        <div className="px-5 mb-6">
          <h2 className="font-serif text-lg text-[#1A1A1A] mb-3">Q&A</h2>
          <div className="space-y-3">
            {answeredQuestions.map((q: any) => (
              <div key={q.id} className="border border-black/8 rounded-2xl p-4">
                <p className="text-sm font-sans font-medium text-[#1A1A1A] mb-2">{q.content}</p>
                <p className="text-sm font-sans text-[#1A1A1A]/60">{q.answer}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floating action buttons */}
      <div className="fixed bottom-24 left-0 right-0 flex justify-center gap-3 px-5 z-40">
        <motion.button whileTap={{ scale: 0.95 }} onClick={() => setShowComplimentModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#FFFEFD] border border-black/10 rounded-full shadow-md text-sm font-sans text-[#1A1A1A]/70">
          <Heart size={15} className="text-[#994EA8]" /> Compliment
        </motion.button>
        <motion.button whileTap={{ scale: 0.95 }} onClick={() => setShowQuestionModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#FFFEFD] border border-black/10 rounded-full shadow-md text-sm font-sans text-[#1A1A1A]/70">
          <HelpCircle size={15} /> Ask
        </motion.button>
        {!profile.isConnected && !profile.requestSent && (
          <motion.button whileTap={{ scale: 0.95 }} onClick={() => setShowConnectModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#1A1A1A] rounded-full shadow-md text-sm font-sans text-white">
            <UserPlus size={15} /> Connect
          </motion.button>
        )}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showConnectModal && (
          <Modal onClose={() => setShowConnectModal(false)} title={`Connect with ${profile.name}`}>
            <textarea className="input-field resize-none mb-4" rows={3}
              placeholder="Add a message (optional)..."
              value={connectMsg} onChange={(e) => setConnectMsg(e.target.value)} />
            <button onClick={handleConnect} disabled={sendRequest.isPending} className="btn-primary w-full">
              {sendRequest.isPending ? <Spinner size={18} color="#FFFEFD" /> : 'Send request'}
            </button>
          </Modal>
        )}
        {showComplimentModal && (
          <Modal onClose={() => setShowComplimentModal(false)} title="Send a compliment">
            <textarea className="input-field resize-none mb-3" rows={3}
              placeholder="Say something kind..." value={complimentText} onChange={(e) => setComplimentText(e.target.value)} />
            <label className="flex items-center gap-2 text-sm font-sans text-[#1A1A1A]/60 mb-4 cursor-pointer">
              <input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} className="rounded" />
              Send anonymously
            </label>
            <button onClick={handleCompliment} disabled={!complimentText.trim()} className="btn-purple w-full">
              <Send size={15} /> Send compliment
            </button>
          </Modal>
        )}
        {showQuestionModal && (
          <Modal onClose={() => setShowQuestionModal(false)} title="Ask a question">
            <textarea className="input-field resize-none mb-3" rows={3}
              placeholder="What would you like to ask?" value={questionText} onChange={(e) => setQuestionText(e.target.value)} />
            <label className="flex items-center gap-2 text-sm font-sans text-[#1A1A1A]/60 mb-4 cursor-pointer">
              <input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} className="rounded" />
              Ask anonymously
            </label>
            <button onClick={handleQuestion} disabled={!questionText.trim()} className="btn-primary w-full">
              <Send size={15} /> Send question
            </button>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
};
