import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { messagesService } from '../services/api';

export const useConversations = () =>
  useQuery({ queryKey: ['conversations'], queryFn: () => messagesService.getConversations().then((r) => r.data) });

export const useMessages = (conversationId: string) =>
  useQuery({
    queryKey: ['messages', conversationId],
    queryFn: () => messagesService.getMessages(conversationId).then((r) => r.data),
    enabled: !!conversationId,
    refetchInterval: 3000,
  });

export const useSendMessage = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: messagesService.send,
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['messages', vars.conversationId] });
      qc.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
};
