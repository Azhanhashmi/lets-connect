import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { notificationsService } from '../services/api';
import { useNotificationStore } from '../store/notificationStore';
import { useEffect } from 'react';

export const useNotifications = () => {
  const { setNotifications } = useNotificationStore();
  const query = useQuery({
    queryKey: ['notifications'],
    queryFn: () => notificationsService.getAll().then((r) => r.data),
    refetchInterval: 30000,
  });
  useEffect(() => { if (query.data) setNotifications(query.data); }, [query.data]);
  return query;
};

export const useMarkRead = () => {
  const qc = useQueryClient();
  const { markRead } = useNotificationStore();
  return useMutation({
    mutationFn: (id: string) => notificationsService.markRead(id),
    onSuccess: (_, id) => { markRead(id); qc.invalidateQueries({ queryKey: ['notifications'] }); },
  });
};
