import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { profileService } from '../services/api';

export const useProfile = (username: string) =>
  useQuery({
    queryKey: ['profile', username],
    queryFn: () => profileService.getProfile(username).then((r) => r.data),
    enabled: !!username,
  });

export const useUpdateProfile = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: profileService.updateProfile,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['me'] }),
  });
};

export const useUploadAvatar = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: profileService.uploadAvatar,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['me'] }),
  });
};
