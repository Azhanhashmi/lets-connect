import axios, { AxiosError } from 'axios';

const BASE_URL = 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 10000,
});

// Request interceptor - attach token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('connectly_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Response interceptor - handle 401
api.interceptors.response.use(
  (res) => res,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('connectly_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth
export const authService = {
  register: (data: { name: string; email: string; username: string; password: string }) =>
    api.post('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  me: () => api.get('/auth/me'),
};

// Profile
export const profileService = {
  getProfile: (username: string) => api.get(`/profile/${username}`),
  updateProfile: (data: Partial<import('../types').User>) => api.put('/profile', data),
  uploadAvatar: (file: File) => {
    const form = new FormData();
    form.append('avatar', file);
    return api.post('/profile/avatar', form, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
};

// Requests
export const requestsService = {
  send: (data: { receiverId: string; message?: string }) => api.post('/requests/send', data),
  pending: () => api.get('/requests/pending'),
  accept: (id: string) => api.post(`/requests/accept/${id}`),
  pass: (id: string) => api.post(`/requests/pass/${id}`),
  later: (id: string) => api.post(`/requests/later/${id}`),
  getLater: () => api.get('/requests/later'),
};

// Connections
export const connectionsService = {
  getAll: () => api.get('/connections'),
};

// Messages
export const messagesService = {
  getConversations: () => api.get('/conversations'),
  getMessages: (conversationId: string) => api.get(`/messages/${conversationId}`),
  send: (data: { conversationId: string; content: string }) => api.post('/messages', data),
};

// Compliments
export const complimentsService = {
  send: (data: { receiverId: string; content: string; anonymous?: boolean }) => api.post('/compliments', data),
  get: (username: string) => api.get(`/compliments/${username}`),
  approve: (id: string) => api.patch(`/compliments/${id}/approve`),
  delete: (id: string) => api.delete(`/compliments/${id}`),
};

// Questions
export const questionsService = {
  ask: (data: { targetId: string; content: string; anonymous?: boolean }) => api.post('/questions', data),
  answer: (id: string, data: { answer: string }) => api.post(`/questions/${id}/answer`, data),
  get: (username: string) => api.get(`/questions/${username}`),
};

// Notifications
export const notificationsService = {
  getAll: () => api.get('/notifications'),
  markRead: (id: string) => api.patch(`/notifications/${id}/read`),
};
